
<!DOCTYPE html>
<html>
  <head>
    <title>Greeting</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/wp.css">
  </head>
  
  <body>  
    <p>
    Hello <?php echo e($name); ?>.
    Next year, you will be <?php echo e($age + 1); ?> years old.

    <hr>
  </body>
</html>

<?php /**PATH /var/www/html/webAppDev/week4/task3/greeting/resources/views/greeting.blade.php ENDPATH**/ ?>