
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Foreach loop example</title>
        <link rel="stylesheet" href="wp.css" type="text/css">

    </head>
    <body>
            <table class="bordered">
                    <!-- table header -->
                    <tr><th>Name</th><th>Value</th></tr>
                    <?php $__empty_1 = true; $__currentLoopData = $get; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                    <?php if($loop->index %2 == 0): ?>
                        <tr style="background-color:#C0C0C0"><td><?php echo e($name); ?>:</td><td><?php echo e($value); ?></td></tr>
                    <?php elseif($loop->index %2 != 0): ?>
                        <tr><td><?php echo e($name); ?>:</td><td><?php echo e($value); ?></td></tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td>No URL variable</td></tr>
                    <?php endif; ?>
            </table>
            

    </body>
</html>
<?php /**PATH /var/www/html/webAppDev/week4/task3/foreach/resources/views/foreach.blade.php ENDPATH**/ ?>