<?php $__env->startSection('title'); ?>
Greeting
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('content'); ?>
    <p>
    Hello <?php echo e($name); ?>.
    Next year, you will be <?php echo e($age + 1); ?> years old.

    <hr>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week4/task4/greeting_laravel/resources/views/greeting.blade.php ENDPATH**/ ?>