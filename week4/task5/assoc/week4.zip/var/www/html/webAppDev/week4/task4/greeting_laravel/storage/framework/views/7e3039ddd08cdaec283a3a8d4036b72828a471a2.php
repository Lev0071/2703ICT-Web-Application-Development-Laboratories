<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/wp.css">
  </head>
  
  <body> 
    <?php echo $__env->yieldContent('content'); ?>
  </body>
</html><?php /**PATH /var/www/html/webAppDev/week4/task4/greeting_laravel/resources/views/layouts/master.blade.php ENDPATH**/ ?>