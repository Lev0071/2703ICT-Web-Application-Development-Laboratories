<?php $__env->startSection('title'); ?>
Web Programming Examples
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <form method="post" action="greetingPost">
      <?php echo e(csrf_field()); ?>

  <table>
    <tr><td>Your name:</td> <td><input type="text" name="name"></td></tr>
    <tr><td>Your age:</td> <td><input type="text" name="age"></td></tr>
    <tr><td colspan=2><input type="submit" value="Submit"></td></tr>
  </table>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/week4/task4/greeting_laravel/resources/views/greetingForm.blade.php ENDPATH**/ ?>